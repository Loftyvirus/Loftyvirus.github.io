mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 9.1.0, for Linux (x86_64)
--
-- Host: localhost    Database: bca
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question_papers`
--

DROP TABLE IF EXISTS `question_papers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_papers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `semester_id` int NOT NULL,
  `season_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `year` int NOT NULL,
  `question_text` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `semester_id` (`semester_id`),
  KEY `season_id` (`season_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `question_papers_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`),
  CONSTRAINT `question_papers_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `seasons` (`id`),
  CONSTRAINT `question_papers_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_papers`
--

LOCK TABLES `question_papers` WRITE;
/*!40000 ALTER TABLE `question_papers` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_papers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seasons`
--

DROP TABLE IF EXISTS `seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `season_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `season_name` (`season_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seasons`
--

LOCK TABLES `seasons` WRITE;
/*!40000 ALTER TABLE `seasons` DISABLE KEYS */;
INSERT INTO `seasons` VALUES (2,'Fall'),(1,'Spring');
/*!40000 ALTER TABLE `seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semesters`
--

DROP TABLE IF EXISTS `semesters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `semesters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `semester_number` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `semester_number` (`semester_number`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semesters`
--

LOCK TABLES `semesters` WRITE;
/*!40000 ALTER TABLE `semesters` DISABLE KEYS */;
INSERT INTO `semesters` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8);
/*!40000 ALTER TABLE `semesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_code` varchar(20) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `semester_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_code` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'ENG 121','English for IT Professional',1),(2,'MTH 131','Mathematics I',1),(3,'ELX 111','Digital Logic System',1),(4,'CMP 116','Computer Fundamental and Application',1),(5,'CMP 117','Programming Logic and Techniques',1),(6,'CMP 111','Computer Application Workshop',1),(7,'ENG 122','Business and Technical Communication',2),(8,'MTH 132','Mathematics II',2),(9,'ACC 131','Financial Accounting',2),(10,'CMP 118','Programming in C',2),(11,'ELX 112','Microprocessor and Computer Architecture',2),(12,'PRJ 151','Project I',2),(13,'CMP 215','Object Oriented Programming in Java',3),(14,'CMP 227','Data Structure & Algorithms',3),(15,'CMP 221','System Analysis and Project Management',3),(16,'CMP 380','Web Technologies I',3),(17,'CMP 230','Operating System',3),(18,'CMP 323','Software Engineering',4),(19,'CMP 226','Database Management System',4),(20,'CMP 242','Computer Graphics and Multimedia Technology',4),(21,'MTH 320','Probability and Statistics',4),(22,'CMP 402','Web Technologies II',4),(23,'PRJ 251','Project II',4),(24,'MTH 230','Numerical Methods',5),(25,'CMP 317','DotNet Technology',5),(26,'CMP 336','Data Communication and Computer Network',5),(27,'ELE 322','Research Methodology',5),(28,'MTH 330','Mathematical Foundation of Computer Science',5),(29,'CMP 316','Data Science and Analytics',6),(30,'CMP 314','Management Information System',6),(31,'CMP 350','Simulation and Modeling',6),(32,'MGT 322','Organization Management',6),(33,'ELE 001','Elective I',6),(34,'PRJ 351','Project III',6),(35,'CMP 401','Cyber Law and Professional Ethics',7),(36,'CMP 404','Mobile Application Development Technology',7),(37,'ECO 311','Applied Economics',7),(38,'INT 461','Internship',7),(39,'ELE 002','Elective II',7),(40,'CMP 415','Cloud Computing',8),(41,'CMP 416','Digital Economy',8),(42,'ELE 003','Elective III',8),(43,'PRJ 451','Project IV',8);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-28 11:13:18
